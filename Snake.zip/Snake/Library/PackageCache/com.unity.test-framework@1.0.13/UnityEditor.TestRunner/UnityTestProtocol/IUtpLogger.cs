namespace UnityEditor.TestTools.TestRunner.UnityTestProtocol
{
    interface IUtpLogger
    {
        void Log(Message msg);
    }
}
